public class Paladin extends Knight {
	public Paladin(int baseHp, int wp) {
		
	}

	@Override
	public double getCombatScore() {
		return 1.0;
	}
}
