public class Knight extends Fighter {
    public Knight(int baseHp, int wp) {
        
    }

    @Override
    public double getCombatScore() {
        return 1.0;
    }
}
